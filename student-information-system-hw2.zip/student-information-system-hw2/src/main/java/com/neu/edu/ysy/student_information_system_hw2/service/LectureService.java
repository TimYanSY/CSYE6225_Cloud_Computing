package com.neu.edu.ysy.student_information_system_hw2.service;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DeleteItemOutcome;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.google.gson.Gson;
import com.neu.edu.ysy.student_information_system_hw2.module.Lecture;

@Path("/lecture")
public class LectureService {
	static AmazonDynamoDB client;
	static BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials("SECRET", "SECRET//SECRET");

	private static void init() throws Exception {
//		ProfileCredentialsProvider credentialsProvider =
//				new ProfileCredentialsProvider();
//		credentialsProvider.getCredentials();
		
		client = AmazonDynamoDBClientBuilder
						.standard()
						.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials))
						.withRegion("us-west-2")
						.build();
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String test() {
		return "test";
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{lectureId}")
	public String getLecture(@PathParam("lectureId") long lectureId) throws Exception {
		init();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table table = dynamoDB.getTable("Lecture");
		Item item = table.getItem("id", lectureId);
		if (item == null) {
			return null;
		}
		return item.toJSON();
	}

	@POST
	@Path("/create")
	@Produces(MediaType.APPLICATION_JSON)
	public String postLectre(String json) throws Exception {
		init();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table lectureTable = dynamoDB.getTable("Lecture");
		Gson gson = new Gson();
		Lecture lecture = gson.fromJson(json, Lecture.class);
		Table courseTable = dynamoDB.getTable("Course");
		Item courseItem = courseTable.getItem("name", lecture.getCourse());
		if (courseItem == null) {
			return null;
		}
		Item lectureItem = new Item()
				.withPrimaryKey("id", lecture.getId())
				.withString("notes", lecture.getNotes())
				.withString("materials", lecture.getMaterials())
				.withString("course", lecture.getCourse());
		PutItemOutcome outcome = lectureTable.putItem(lectureItem);
		return gson.toJson(outcome);
	}

	@DELETE
	@Path("/delete")
	@Produces(MediaType.APPLICATION_JSON)
	public String deleteLecture(String json) throws Exception {
		init();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table lectureTable = dynamoDB.getTable("Lecture");
		Gson gson = new Gson();
		Lecture lecture = gson.fromJson(json, Lecture.class);
		DeleteItemOutcome outcome = lectureTable.deleteItem("id", lecture.getId());
		return gson.toJson(outcome);
	}
}
