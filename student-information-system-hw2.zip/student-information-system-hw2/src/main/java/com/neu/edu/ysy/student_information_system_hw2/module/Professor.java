package com.neu.edu.ysy.student_information_system_hw2.module;

public class Professor {
	long id;
	String name;
	String course;
	public Professor(long id, String name, String courseName) {
		super();
		this.id = id;
		this.name = name;
		this.course = courseName;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCourseName() {
		return course;
	}
	public void setCourseName(String courseName) {
		this.course = courseName;
	}
	
}
