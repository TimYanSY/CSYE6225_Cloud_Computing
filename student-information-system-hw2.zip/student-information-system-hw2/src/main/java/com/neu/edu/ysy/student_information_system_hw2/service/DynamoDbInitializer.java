package com.neu.edu.ysy.student_information_system_hw2.service;

import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.model.AttributeDefinition;
import com.amazonaws.services.dynamodbv2.model.CreateTableRequest;
import com.amazonaws.services.dynamodbv2.model.KeySchemaElement;
import com.amazonaws.services.dynamodbv2.model.KeyType;
import com.amazonaws.services.dynamodbv2.model.ProvisionedThroughput;
import com.amazonaws.services.dynamodbv2.model.ScalarAttributeType;
import com.amazonaws.services.dynamodbv2.util.TableUtils;
import com.amazonaws.services.dynamodbv2.util.TableUtils.TableNeverTransitionedToStateException;

public class DynamoDbInitializer {
static AmazonDynamoDB dynamoDb;
	
	private static void init() throws Exception {
		ProfileCredentialsProvider credentialsProvider = 
				new ProfileCredentialsProvider();
		credentialsProvider.getCredentials();
		
		dynamoDb = AmazonDynamoDBClientBuilder
						.standard()
						.withCredentials(credentialsProvider)
						.withRegion("us-west-2")
						.build();
	}
	
	private static void createStudentTable() {
		String tableName = "Student";
		CreateTableRequest createTableRequest = new CreateTableRequest()
				.withTableName(tableName)
				.withKeySchema(
						new KeySchemaElement()
						.withAttributeName("id")
						.withKeyType(KeyType.HASH))
				.withAttributeDefinitions(
						new AttributeDefinition()
						.withAttributeName("id")
						.withAttributeType(ScalarAttributeType.N))
				.withProvisionedThroughput(
						new ProvisionedThroughput()
						.withReadCapacityUnits(3L)
						.withWriteCapacityUnits(3L));
		TableUtils.createTableIfNotExists(dynamoDb, createTableRequest);
		try {
			TableUtils.waitUntilActive(dynamoDb, tableName);
		} catch (TableNeverTransitionedToStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void createProfessorTable() {
		String tableName = "Professor";
		CreateTableRequest createTableRequest = new CreateTableRequest()
				.withTableName(tableName)
				.withKeySchema(
						new KeySchemaElement()
						.withAttributeName("id")
						.withKeyType(KeyType.HASH))
				.withAttributeDefinitions(
						new AttributeDefinition()
						.withAttributeName("id")
						.withAttributeType(ScalarAttributeType.N))
				.withProvisionedThroughput(
						new ProvisionedThroughput()
						.withReadCapacityUnits(3L)
						.withWriteCapacityUnits(3L));
		TableUtils.createTableIfNotExists(dynamoDb, createTableRequest);
		try {
			TableUtils.waitUntilActive(dynamoDb, tableName);
		} catch (TableNeverTransitionedToStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void createCourseTable() {
		String tableName = "Course";
		CreateTableRequest createTableRequest = new CreateTableRequest()
				.withTableName(tableName)
				.withKeySchema(
						new KeySchemaElement()
						.withAttributeName("name")
						.withKeyType(KeyType.HASH))
				.withAttributeDefinitions(
						new AttributeDefinition()
						.withAttributeName("name")
						.withAttributeType(ScalarAttributeType.S))
				.withProvisionedThroughput(
						new ProvisionedThroughput()
						.withReadCapacityUnits(3L)
						.withWriteCapacityUnits(3L));
		TableUtils.createTableIfNotExists(dynamoDb, createTableRequest);
		try {
			TableUtils.waitUntilActive(dynamoDb, tableName);
		} catch (TableNeverTransitionedToStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void createAnnouncementTable() {
		String tableName = "Announcement";
		CreateTableRequest createTableRequest = new CreateTableRequest()
				.withTableName(tableName)
				.withKeySchema(
						new KeySchemaElement()
						.withAttributeName("id")
						.withKeyType(KeyType.HASH))
				.withAttributeDefinitions(
						new AttributeDefinition()
						.withAttributeName("id")
						.withAttributeType(ScalarAttributeType.N))
				.withProvisionedThroughput(
						new ProvisionedThroughput()
						.withReadCapacityUnits(3L)
						.withWriteCapacityUnits(3L));
		TableUtils.createTableIfNotExists(dynamoDb, createTableRequest);
		try {
			TableUtils.waitUntilActive(dynamoDb, tableName);
		} catch (TableNeverTransitionedToStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void createLectureTable() {
		String tableName = "Lecture";
		CreateTableRequest createTableRequest = new CreateTableRequest()
				.withTableName(tableName)
				.withKeySchema(
						new KeySchemaElement()
						.withAttributeName("id")
						.withKeyType(KeyType.HASH))
				.withAttributeDefinitions(
						new AttributeDefinition()
						.withAttributeName("id")
						.withAttributeType(ScalarAttributeType.N))
				.withProvisionedThroughput(
						new ProvisionedThroughput()
						.withReadCapacityUnits(3L)
						.withWriteCapacityUnits(3L));
		TableUtils.createTableIfNotExists(dynamoDb, createTableRequest);
		try {
			TableUtils.waitUntilActive(dynamoDb, tableName);
		} catch (TableNeverTransitionedToStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		
	public static void main(String args[]) throws Exception {
		init();
		createStudentTable();
		createCourseTable();
		createProfessorTable();
		createAnnouncementTable();
		createLectureTable();
	}
}
