package com.neu.edu.ysy.student_information_system_hw2.module;

public class Course {
	String name;

	public Course(String name) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
