package com.neu.edu.ysy.student_information_system_hw2.module;

public class Lecture {
	long id;
	String notes;
	String materials;
	String course;
	
	public Lecture(long id, String notes, String materials, String course) {
		this.id = id;
		this.notes = notes;
		this.materials = materials;
		this.course = course;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getMaterials() {
		return materials;
	}

	public void setMaterials(String materials) {
		this.materials = materials;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}
	
}
