package com.neu.edu.ysy.student_information_system_hw2.module;

public class Announcement {
	long id;
	long profId;
	String content;
	public Announcement(long id, long profId, String content) {
		super();
		this.id = id;
		this.profId = profId;
		this.content = content;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getProfId() {
		return profId;
	}
	public void setProfId(long profId) {
		this.profId = profId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
}
