package com.neu.edu.ysy.student_information_system_hw2.service;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.google.gson.Gson;
import com.neu.edu.ysy.student_information_system_hw2.module.Announcement;
import com.neu.edu.ysy.student_information_system_hw2.module.Professor;

@Path("/professor")
public class ProfessorService {
	static AmazonDynamoDB client;
	static BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials("SECRET", "SECRET//SECRET");

	private static void init() throws Exception {
//		ProfileCredentialsProvider credentialsProvider =
//				new ProfileCredentialsProvider();
//		credentialsProvider.getCredentials();

		client = AmazonDynamoDBClientBuilder
						.standard()
						.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials))
						.withRegion("us-west-2")
						.build();
	}


	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getStudent(@PathParam("id") long id) throws Exception {
		init();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table table = dynamoDB.getTable("Professor");
		Item item = table.getItem("id", id);
		if (item == null) {
			return null;
		}
		return item.toJSON();
	}

	@POST
	@Path("/create")
	@Produces(MediaType.APPLICATION_JSON)
	public String createStudent(String json) throws Exception {
		init();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table table = dynamoDB.getTable("Professor");
		Gson gson = new Gson();
		Professor professor = gson.fromJson(json, Professor.class);
		if (table.getItem("id", professor.getId()) != null) {
			return null;
		}
		System.out.println(professor.getCourseName());
		Item item = new Item()
				.withPrimaryKey("id", professor.getId())
				.withString("name", professor.getName())
				.withString("course", professor.getCourseName());
		PutItemOutcome outcome = table.putItem(item);
		return gson.toJson(outcome);
	}

	@POST
	@Path("/announce")
	@Produces(MediaType.APPLICATION_JSON)
	public String createAnnouncement(String json) throws Exception {
		init();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table announceTable = dynamoDB.getTable("Announcement");
		Table profTable = dynamoDB.getTable("Professor");
		Table courseTable = dynamoDB.getTable("Course");
		Gson gson = new Gson();
		Announcement announcement = gson.fromJson(json, Announcement.class);
		Item profItem = profTable.getItem("id", announcement.getProfId());
		if (profItem == null) {
			return null;
		}
		Item courseItem = courseTable.getItem("name", profItem.get("course"));
		if (courseItem == null) {
			return null;
		}
		Item announceItem = new Item()
				.withPrimaryKey("id", announcement.getId())
				.withLong("profId", announcement.getProfId())
				.withString("content", announcement.getContent())
				.withString("course", courseItem.getString("name"));
		PutItemOutcome outcome = announceTable.putItem(announceItem);
		return gson.toJson(outcome);
	}
}
