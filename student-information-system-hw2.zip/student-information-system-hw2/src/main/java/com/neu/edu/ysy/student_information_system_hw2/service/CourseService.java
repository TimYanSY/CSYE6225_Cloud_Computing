package com.neu.edu.ysy.student_information_system_hw2.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DeleteItemOutcome;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.ScanOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.CreateTopicRequest;
import com.amazonaws.services.sns.model.CreateTopicResult;
import com.amazonaws.services.sns.model.DeleteTopicRequest;
import com.google.gson.Gson;
import com.neu.edu.ysy.student_information_system_hw2.module.Course;

@Path("/course")
public class CourseService {
	static AmazonDynamoDB client;
	static AmazonSNSClient snsClient;
	static String arn = "arn:aws:sns:us-west-2:653972734361:";
	static BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials("SECRET", "SECRET//SECRET");

	private static void snsInit() {
//		ProfileCredentialsProvider credentialsProvider =
//				new ProfileCredentialsProvider();
//		credentialsProvider.getCredentials();

		snsClient = new AmazonSNSClient(new AWSStaticCredentialsProvider(basicAWSCredentials));
		snsClient.setRegion(Region.getRegion(Regions.US_WEST_2));
	}

	private static void init() throws Exception {
//		ProfileCredentialsProvider credentialsProvider =
//				new ProfileCredentialsProvider();
//		credentialsProvider.getCredentials();

		client = AmazonDynamoDBClientBuilder
						.standard()
						.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials))
						.withRegion("us-west-2")
						.build();
	}

	@GET
	@Path("/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getCourse(@PathParam("name") String name) throws Exception {
		init();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table table = dynamoDB.getTable("Course");
		Item item = table.getItem("name", name);
		if (item == null) {
			return null;
		}
		return item.toJSON();
	}

	@POST
	@Path("/create")
	@Produces(MediaType.APPLICATION_JSON)
	public String createStudent(String json) throws Exception {
		init();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table table = dynamoDB.getTable("Course");
		Gson gson = new Gson();
		Course course = gson.fromJson(json, Course.class);
		if (table.getItem("name", course.getName()) != null) {
			return null;
		}
		Item item = new Item()
				.withPrimaryKey("name", course.getName());
		PutItemOutcome outcome = table.putItem(item);
		snsInit();
		new CreateTopicRequest(course.getName());
		return gson.toJson(outcome);
	}

	@GET
	@Path("/student/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getRegisteredCourses(@PathParam("name") String name) throws Exception {
		init();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table registrationTable = dynamoDB.getTable("Registration");
		Map<String, Object> expressionAttributeValues = new HashMap<String, Object>();
		expressionAttributeValues.put(":name", name);
		ItemCollection<ScanOutcome> items = registrationTable.scan("course = :name", null, expressionAttributeValues);
		Iterator<Item> iterator = items.iterator();
		ArrayList<Long> students = new ArrayList<>();
		while (iterator.hasNext()) {
			Item tmp = iterator.next();
			students.add(tmp.getLong("studentId"));
        }
		return new Gson().toJson(students);
	}

	@DELETE
	@Path("/delete")
	@Produces(MediaType.APPLICATION_JSON)
	public String deleteCourse(String json) throws Exception {
		init();
		Gson gson = new Gson();
		Course course = gson.fromJson(json, Course.class);
		DynamoDB dynamoDB = new DynamoDB(client);
		// delete course in course table
		Table courseTable = dynamoDB.getTable("Course");
		Item courseItem = courseTable.getItem("name", course.getName());
		if (courseItem == null) {
			return null;
		}
		DeleteItemOutcome deleteCourseItemOutcome = courseTable.deleteItem("name", course.getName());
		//delete sns topic
		snsInit();
		//delete an SNS topic
		DeleteTopicRequest deleteTopicRequest = new DeleteTopicRequest(arn + course.getName());
		snsClient.deleteTopic(deleteTopicRequest);
		// delete in registration table
		Table registrationTable = dynamoDB.getTable("Registration");
		Map<String, Object> expressionAttributeValues = new HashMap<String, Object>();
		expressionAttributeValues.put(":course", course.getName());
		ItemCollection<ScanOutcome> items = registrationTable.scan("course = :course", null, expressionAttributeValues);
		Iterator<Item> iterator = items.iterator();
		while (iterator.hasNext()) {
			Item tmp = iterator.next();
			registrationTable.deleteItem("registration", tmp.getString("registration"));
        }
		return gson.toJson(snsClient.getCachedResponseMetadata(deleteTopicRequest));
	}
}
