package com.neu.edu.ysy.student_information_system_hw2.module;

public class Registration {
	long id;
	long studentId;
	String courseName;
	
	public Registration(long id, long studentId, String courseName) {
		super();
		this.id = id;
		this.studentId = studentId;
		this.courseName = courseName;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getStudentId() {
		return studentId;
	}
	public void setStudentId(long studentId) {
		this.studentId = studentId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
}
