package com.neu.edu.ysy.student_information_system_hw2.service;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.DynamodbEvent;
import com.amazonaws.services.lambda.runtime.events.DynamodbEvent.DynamodbStreamRecord;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClientBuilder;
import com.amazonaws.services.sns.model.PublishRequest;

public class NewAnnouncementHandler implements RequestHandler<DynamodbEvent, String>{
	private AmazonSNS SNS_Client = AmazonSNSClientBuilder.standard()
			.withRegion(Regions.US_WEST_2).build();
	private static String COURSE_RELATED_SNS_TOPIC = "arn:aws:sns:us-west-2:SECRET:";	

	@Override
	public String handleRequest(DynamodbEvent input, Context context) {
		// TODO Auto-generated method stub
		for(DynamodbStreamRecord record : input.getRecords()) {
			if (record == null) {
				continue;
			}
			context.getLogger().log("Input: " + record);
			String courseName = "";
			String content = "";
			try {
				courseName = getCourseName(record);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				content = getCourseContent(record);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			context.getLogger().log("My course name is : " + courseName);
			context.getLogger().log("My content is : " + content);
			sendEmailNotification(courseName, content);
		}
		return "";
	}

	private void sendEmailNotification(String courseName, String content) {
		PublishRequest publishRequest = new PublishRequest(COURSE_RELATED_SNS_TOPIC + courseName, content, courseName);
    	SNS_Client.publish(publishRequest);
	}

	private String getCourseName(DynamodbStreamRecord record) throws Exception {
		String courseName = "";
		courseName = record.getDynamodb().getNewImage().get("course").getS();
		return courseName;
	}

	private String getCourseContent(DynamodbStreamRecord record) throws Exception {
		String content = "";
		content = record.getDynamodb().getNewImage().get("content").getS();
		return content;
	}
}
