package com.neu.edu.ysy.student_information_system_hw2.service;

import java.awt.List;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.http.impl.client.BasicCredentialsProvider;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.PutItemOutcome;
import com.amazonaws.services.dynamodbv2.document.ScanOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.CreateTopicRequest;
import com.amazonaws.services.sns.model.CreateTopicResult;
import com.amazonaws.services.sns.model.SubscribeRequest;
import com.google.gson.Gson;
import com.neu.edu.ysy.student_information_system_hw2.module.Registration;
import com.neu.edu.ysy.student_information_system_hw2.module.Student;


@Path("/student")
public class StudentService {
	static AmazonDynamoDB client;
	static String arn = "arn:aws:sns:us-west-2:SECRET:";
	static AmazonSNSClient snsClient;
	static BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials("SECRET", "SECRET//SECRET");

	private static void snsInit() {
//		ProfileCredentialsProvider credentialsProvider =
//				new ProfileCredentialsProvider();
//		credentialsProvider.getCredentials();
		snsClient = new AmazonSNSClient(new AWSStaticCredentialsProvider(basicAWSCredentials));
		snsClient.setRegion(Region.getRegion(Regions.US_WEST_2));
	}

	private static void init() throws Exception {
//		ProfileCredentialsProvider credentialsProvider =
//				new ProfileCredentialsProvider();
//		credentialsProvider.getCredentials();

		client = AmazonDynamoDBClientBuilder
						.standard()
						.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials))
						.withRegion("us-west-2")
						.build();
	}

	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getStudent(@PathParam("id") long id) throws Exception {
		init();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table table = dynamoDB.getTable("Student");
		Item item = table.getItem("id", id);
		if (item == null) {
			return null;
		}
		return item.toJSON();
	}

	@POST
	@Path("/create")
	@Produces(MediaType.APPLICATION_JSON)
	public String createStudent(String json) throws Exception {
		init();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table table = dynamoDB.getTable("Student");
		Gson gson = new Gson();
		Student student = gson.fromJson(json, Student.class);
		if (table.getItem("id", student.getId()) != null) {
			return null;
		}
		Item item = new Item()
				.withPrimaryKey("id", student.getId())
				.withString("name", student.getName())
				.withString("email", student.getEmail());
		PutItemOutcome outcome = table.putItem(item);
		return gson.toJson(outcome);
	}

	@POST
	@Path("/register")
	@Produces(MediaType.APPLICATION_JSON)
	public String register(String json) throws Exception {
		init();
		snsInit();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table studentTable = dynamoDB.getTable("Student");
		Table courseTable = dynamoDB.getTable("Course");
		Gson gson = new Gson();
		Registration registration = gson.fromJson(json, Registration.class);
		Item studentItem = studentTable.getItem("id", registration.getStudentId());
		// make sure student with corresponding id is in the table
		if (studentItem == null) {
			return null;
		}
		Item courseItem = courseTable.getItem("name", registration.getCourseName());
		// make sure course with corresponding id is in the table
		if (courseItem == null) {
			return null;
		}
		// course topic
		String topic = arn + courseItem.getString("name");
		System.out.println(topic);
		// create course topic
		CreateTopicRequest createTopicRequest = new CreateTopicRequest(courseItem.getString("name"));
		CreateTopicResult createTopicResult = snsClient.createTopic(createTopicRequest);
		// subscribe the topic with email
		SubscribeRequest subscribeRequest = new SubscribeRequest(topic, "email", studentItem.getString("email"));
		snsClient.subscribe(subscribeRequest);
		// post student to the register course
		Table registrationTable = dynamoDB.getTable("Registration");
		Item item = new Item()
				.withPrimaryKey("registration", "" + registration.getStudentId() + registration.getCourseName())
				.withLong("studentId", registration.getStudentId())
				.withString("course", registration.getCourseName());
		PutItemOutcome outcome = registrationTable.putItem(item);
		return gson.toJson(outcome);
	}

	@GET
	@Path("/course/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getRegisteredCourses(@PathParam("id") long id) throws Exception {
		init();
		snsInit();
		DynamoDB dynamoDB = new DynamoDB(client);
		Table registrationTable = dynamoDB.getTable("Registration");
		Map<String, Object> expressionAttributeValues = new HashMap<String, Object>();
		expressionAttributeValues.put(":id", id);
		ItemCollection<ScanOutcome> items = registrationTable.scan("studentId = :id", null, expressionAttributeValues);
		Iterator<Item> iterator = items.iterator();
		ArrayList<String> courses = new ArrayList<>();
		while (iterator.hasNext()) {
			Item tmp = iterator.next();
			courses.add(tmp.getString("course"));
        }
		return new Gson().toJson(courses);
	}

}
