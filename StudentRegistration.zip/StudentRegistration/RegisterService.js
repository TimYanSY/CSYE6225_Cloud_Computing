const AWS = require("aws-sdk");
exports.handler = (event, context, callback) => {
    // TODO implement
    AWS.config.update({
      region: "us-west-2"
    });
    
    const docClient = new AWS.DynamoDB.DocumentClient();
    const table = "Student";
    
    let params = {
        TableName: table,
        Key: {
            "id": event.id
        }
    };
    // if student has registered finish the function
    // if not mark student as registered
    docClient.get(params, function (err, data) {
        if (err) {
            console.log(err, err.stack);
        } else {
            console.log(data);
            console.log(data.Item.name)
            event.who = data.Item.name;
            if (data.Item.hasRegistered) {
                event.registration = "already registered";
                callback(null, event);
            } else {
                params = {
                    TableName: table,
                    Key: {
                        "id" : event.id
                    },
                    UpdateExpression: "set hasRegistered = :r",
                    ExpressionAttributeValues:{
                        ":r" : true
                    },
                    ReturnValues:"UPDATED_NEW"
                };
                docClient.update(params, function(err, data) {
                    if (err) {
                        console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
                    } else {
                        console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
                        event.registration = "finish registration this time";
                    }
                });
            }
        }
    });
    
    const table2 = "Registration";
    
    const params2 = {
        TableName: table2,
        Item: {
            "registration": event.id + event.course,
            "course": event.course,
            "studentId": event.id,
        }
    };
    
    docClient.put(params2, function(err, data) {
       if (err) {
           console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
       } else {
           console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
       }
    });
    callback(null, event);
};