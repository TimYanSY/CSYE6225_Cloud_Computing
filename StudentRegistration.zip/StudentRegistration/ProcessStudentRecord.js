const AWS = require("aws-sdk");
exports.handler = (event, context, callback) => {
    // if this is a new registration request
    // mark it as "1" in order to go to registration process
    if (event.isNew) {
        event.status = "1";
        callback(null, event);
    } else {
        // for not new registartion, there are two conditions
        // 1 already register, mark as '1' to go through fee check process
        // 2 not register, mark as '0' to go to registar service
        AWS.config.update({
            region: "us-west-2"
        });
        
        const docClient = new AWS.DynamoDB.DocumentClient();
        
        const table = "Registration";
        
        const params = {
            TableName: table,
            Key: {
                registration: event.id + event.course
            }
        }
        
        docClient.get(params, function (err, data) {
            // an error occurred
            if (err) {
                console.log(err, err.stack);
            }
            // successful response
            else {
                // if empty object, this means there is no such registration in the table
                // mark as '0', if not empty, there is such registartion in the table
                Object.keys(data).length ? event.status = "1" : event.status = "0";
                callback(null, event);
            }
        });
    }
    
};