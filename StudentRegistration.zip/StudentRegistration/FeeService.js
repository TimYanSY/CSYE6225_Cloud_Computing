const AWS = require("aws-sdk");
const http = require('http');

exports.handler = (event, context, callback) => {
    // TODO call fee deduct api
    AWS.config.update({
            region: "us-west-2"
    });
    const docClient = new AWS.DynamoDB.DocumentClient();
    
    const table = "Student";
    const table2 = "Course";
    
    const params = {
        TableName: table,
        Key: {
            id: event.id
        }
    };
    
    const params2 = {
        TableName: table2,
        Key: {
            name: event.course
        }
    };
    //default tuition
    let tuition = 1000;
    
    docClient.get(params2, function (err, data) {
        if (err) {
            console.log(err, err.stack);
        } else {
            if (data.Item.tuition) {
                // get current course tuition
                tuition = Number.parseInt(data.Item.tuition, 10);
            }
        }
    });
    
    docClient.get(params, function (err, data) {
        // an error occurred
        if (err) {
            console.log(err, err.stack);
        }
        // successful response
        else {
            if (!data.Item.hasCharged) {
                const options = {
                    host: "default-environment.2age32xank.us-west-2.elasticbeanstalk.com",
                    path: "/webapi/student/deduct",
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    }
                };
                
                const patchData = JSON.stringify({
                    "id": event.id,
                    "tuition": tuition
                });
                
                const req = http.request(options, function (res) {
                    var responseString = "";
                    res.on("data", function (data) {
                        responseString += data;
                        // save all the data from response
                        });
                    res.on("end", function () {
                        console.log(responseString); 
                        // print to console when response ends
                        });
                });
                
                req.write(patchData);
                req.end();
                event.charge = `charged this time for ${tuition}`;
            }
            event.charge = "has charged previously";
        }
    });
    callback(null, event);
};