const AWS = require("aws-sdk");
exports.handler = (event, context, callback) => {
    // The input student should be marked as inactive in the corresponding table
    AWS.config.update({
      region: "us-west-2"
    });
    const docClient = new AWS.DynamoDB.DocumentClient();
    
    const table = "Student";
    
    const params = {
        TableName: table,
        Key: {
            "id" : event.id
        },
        UpdateExpression: "set isActive = :r",
        ExpressionAttributeValues:{
            ":r" : false
        },
        ReturnValues:"UPDATED_NEW"
    }
    console.log("Updating the item...");
    docClient.update(params, function(err, data) {
    if (err) {
        console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
    } else {
        console.log("UpdateItem succeeded:", JSON.stringify(data, null, 2));
    }
    event.isMarkedInactive = true;
    callback(null, event);
    });
};