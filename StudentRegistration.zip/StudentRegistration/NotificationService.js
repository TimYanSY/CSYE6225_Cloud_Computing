const AWS = require('aws-sdk');

exports.handler = (event, context, callback) => {
    if (event.isNew) {
        const sns = new AWS.SNS();
        AWS.config.update({
            region: "us-west-2"
        });
        const docClient = new AWS.DynamoDB.DocumentClient();
        const table = "Student";
        const tblParams = {
            TableName: table,
            Key: {
                id: event.id
            }
        };
        let name = event.id;
        const sendMessage = function () {
            const params = {
                TargetArn: `arn:aws:sns:us-west-2:653972734361:${event.course}`,
                Message: `student ${name} has registered ${event.course}`,
                Subject: 'New Registration'
            };
            sns.publish(params, function(err,data){
                if (err) {
                    console.log('Error sending a message', err);
                } else {
                    console.log('Sent message:', data.MessageId);
                }
            });
        }
        docClient.get(tblParams, function (err, data) {
            if (err) {
                console.log(err, err.stack);
            } else {
                if (data.Item.name) {
                    // get current course tuition
                    name = data.Item.name;
                    sendMessage();
                }
            }
        });
    }
    callback(null, event);
};